// Arthur Config

var AC = AC || {};

AC.KEYS = [];

AC.STATE_HERO_STAND = 0;
AC.STATE_HERO_RUNNING = 1;
AC.STATE_HERO_ATTACK = 2;

AC.FONT = "Tahoma";

AC.ROLE_HERO = 0;
AC.ROLE_ROBOT = 1;

// attack type
var AT = AT || {};
AT.ATTACK = 1;
AT.ATTACK_A = 2;
AT.ATTACK_B = 3;
